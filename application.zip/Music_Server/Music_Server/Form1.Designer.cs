﻿
namespace Music_Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startBut = new System.Windows.Forms.Button();
            this.actLog = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.loadBut = new System.Windows.Forms.Button();
            this.last5Box = new System.Windows.Forms.ListBox();
            this.playlistBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.l5SaveBut = new System.Windows.Forms.Button();
            this.AddSong = new System.Windows.Forms.Button();
            this.RemButt = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startBut
            // 
            this.startBut.Location = new System.Drawing.Point(13, 26);
            this.startBut.Name = "startBut";
            this.startBut.Size = new System.Drawing.Size(75, 23);
            this.startBut.TabIndex = 0;
            this.startBut.Text = "Start server";
            this.startBut.UseVisualStyleBackColor = true;
            this.startBut.Click += new System.EventHandler(this.startBut_Click);
            // 
            // actLog
            // 
            this.actLog.FormattingEnabled = true;
            this.actLog.Location = new System.Drawing.Point(437, 55);
            this.actLog.Name = "actLog";
            this.actLog.Size = new System.Drawing.Size(120, 251);
            this.actLog.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(437, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Activity Log";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Save Playlist";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // loadBut
            // 
            this.loadBut.Location = new System.Drawing.Point(13, 127);
            this.loadBut.Name = "loadBut";
            this.loadBut.Size = new System.Drawing.Size(75, 23);
            this.loadBut.TabIndex = 4;
            this.loadBut.Text = "Load Playlist";
            this.loadBut.UseVisualStyleBackColor = true;
            this.loadBut.Click += new System.EventHandler(this.loadBut_Click);
            // 
            // last5Box
            // 
            this.last5Box.FormattingEnabled = true;
            this.last5Box.Location = new System.Drawing.Point(311, 55);
            this.last5Box.Name = "last5Box";
            this.last5Box.Size = new System.Drawing.Size(120, 251);
            this.last5Box.TabIndex = 5;
            // 
            // playlistBox
            // 
            this.playlistBox.FormattingEnabled = true;
            this.playlistBox.Location = new System.Drawing.Point(185, 55);
            this.playlistBox.Name = "playlistBox";
            this.playlistBox.Size = new System.Drawing.Size(120, 251);
            this.playlistBox.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(311, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Last 5 Songs";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Server Playlist";
            // 
            // l5SaveBut
            // 
            this.l5SaveBut.Location = new System.Drawing.Point(13, 183);
            this.l5SaveBut.Name = "l5SaveBut";
            this.l5SaveBut.Size = new System.Drawing.Size(75, 23);
            this.l5SaveBut.TabIndex = 9;
            this.l5SaveBut.Text = "Save Last 5";
            this.l5SaveBut.UseVisualStyleBackColor = true;
            this.l5SaveBut.Click += new System.EventHandler(this.l5SaveBut_Click);
            // 
            // AddSong
            // 
            this.AddSong.Location = new System.Drawing.Point(13, 224);
            this.AddSong.Name = "AddSong";
            this.AddSong.Size = new System.Drawing.Size(75, 23);
            this.AddSong.TabIndex = 10;
            this.AddSong.Text = "Add Song";
            this.AddSong.UseVisualStyleBackColor = true;
            this.AddSong.Click += new System.EventHandler(this.button3_Click);
            // 
            // RemButt
            // 
            this.RemButt.Location = new System.Drawing.Point(13, 254);
            this.RemButt.Name = "RemButt";
            this.RemButt.Size = new System.Drawing.Size(75, 23);
            this.RemButt.TabIndex = 11;
            this.RemButt.Text = "Remove Song";
            this.RemButt.UseVisualStyleBackColor = true;
            this.RemButt.Click += new System.EventHandler(this.RemButt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 359);
            this.Controls.Add(this.RemButt);
            this.Controls.Add(this.AddSong);
            this.Controls.Add(this.l5SaveBut);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.playlistBox);
            this.Controls.Add(this.last5Box);
            this.Controls.Add(this.loadBut);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.actLog);
            this.Controls.Add(this.startBut);
            this.Name = "Form1";
            this.Text = "Music Server";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startBut;
        private System.Windows.Forms.ListBox actLog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button loadBut;
        private System.Windows.Forms.ListBox last5Box;
        private System.Windows.Forms.ListBox playlistBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button l5SaveBut;
        private System.Windows.Forms.Button AddSong;
        private System.Windows.Forms.Button RemButt;
    }
}

