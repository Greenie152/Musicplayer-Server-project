﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using CsvHelper;
using System.Globalization;
namespace Music_Server
{
    public partial class Form1 : Form
    {
        private MainServer serve = new MainServer();//creates a server class object
        List<string> SongList = new List<string>();
        public Form1()
        {
            InitializeComponent();
            serve.MessageReceived += login_attempt;
        }

        private void startBut_Click(object sender, EventArgs e)
        {
            if (!serve.Running)
            {
                serve.Start("\\\\.\\pipe\\musicpipe");

            }
            else
            {
                startBut.Enabled = false;
                MessageBox.Show("Server already running.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog browser = new OpenFileDialog();
            browser.Title = "Add Song";
            browser.InitialDirectory = @"C:\Users";
            //browser.Filter = "Music files (*.mp3,*.wav)|*.mp3, *.wav";
            browser.FilterIndex = 1;
            browser.RestoreDirectory = true;//creates a browser that allows the user to pick the file they want to add
            if (browser.ShowDialog() == DialogResult.OK)
            {
                string songloc = browser.FileName;
                SongList.Add(songloc);//if the file browser gets an option saves the url to the list
            }
            if (SongList.Count >= 2)
            {
                SortList();//sorts the list after a new element was added
            }
            else
            {
                PopulateSongList();
            }
        }
        private void PopulateSongList()
        {
            playlistBox.Items.Clear();
            foreach (String s in SongList)
            {
                playlistBox.Items.Add(s);
            }
        }
        void login_attempt(byte[] message)
        {
            Invoke(new MainServer.MessageReceivedHandler(DisplayMessageReceived),
                new object[] { message });
        }

        void DisplayMessageReceived(byte[] message)
        {
            ASCIIEncoding encoder = new ASCIIEncoding();
            string str = encoder.GetString(message, 0, message.Length);
            bool playSendCheck = false;
            bool logCheck = false;
            try
            {
                if (Hashing.Verify("S3ndPl@ylist1!", str))
                {
                    playSendCheck = true;
                }
                else if (Hashing.Verify("68764", str))
                {
                    logCheck = true;
                }
            }
            catch
            {

            }
            if (playSendCheck)
            {
                String send = "!";
                foreach (string s in SongList)
                {
                    send += ("," + s);//appends each song in the list to message with a seperation charecter
                }
                ASCIIEncoding en = new ASCIIEncoding();
                byte[] messageBuffer = en.GetBytes(send);
                serve.SendMessage(messageBuffer);
                actLog.Items.Add("Playlist sent to user.");
            }
            else if (logCheck)
            {
                ASCIIEncoding en = new ASCIIEncoding();
                string logcon = "DoneConn";
                logcon = Hashing.Hash(logcon);//hashes the confirmation
                byte[] messageBuffer = en.GetBytes(logcon);

                serve.SendMessage(messageBuffer);
                actLog.Items.Add("User has loggen in.");
            }
            else if (str[0].ToString() == "!")
            {
                int count = 0;
                String temp = "";//sets checker variables
                foreach (char ch in str)//loops through the message
                {
                    if (count == 0)//skips over the flag charecter without excluding later exclamation marks
                    {
                        count++;
                    }
                    else//any other charecter
                    {
                        temp += ch;//builds temp into a complete item
                    }
                }
                last5Box.Items.Add(temp);
                actLog.Items.Add("song added to last 5");
                if(last5Box.Items.Count > 5)
                {
                    last5Box.Items.RemoveAt(0);
                }


            }
            else
            {
                ASCIIEncoding en = new ASCIIEncoding();
                string logDen = "NO";
                logDen = Hashing.Hash(logDen);//hashes the confirmation
                byte[] messageBuffer = en.GetBytes(logDen);

                serve.SendMessage(messageBuffer);
                actLog.Items.Add("Failed login attempted");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Tracklist";
            save.InitialDirectory = @"C:\Users";
            save.FilterIndex = 1;
            save.RestoreDirectory = true;
            if (save.ShowDialog() == DialogResult.OK)
            {
                if (!save.FileName.EndsWith("v"))
                {
                    save.FileName += ".csv";
                }
                using (var write = new StreamWriter(save.FileName))
                using (var csv = new CsvWriter(write, CultureInfo.InvariantCulture))
                {

                    foreach (var song in SongList)
                    {
                        csv.WriteField<String>(song);
                        csv.NextRecord();
                    }

                }
            }
        }

        private void SortList()
        {
            List<string> InsList = new List<string>(SongList);
            InsList = (InsSort(SongList));
            SongList = InsList;
            PopulateSongList();
        }
        static List<string> InsertionSort(List<string> sorter)
        {
            for (int i = 0; i < sorter.Count - 1; i++)
            {
                for (int j = i + 1; j > 0; j--)
                {
                    if (sorter[j - 1].CompareTo(sorter[j]) > 0)
                    {
                        string temp = sorter[j - 1];
                        sorter[j - 1] = sorter[j];
                        sorter[j] = temp;
                    }
                }
            }
            return sorter;
        }
        static public List<string> InsSort(List<string> lis)
        {
            List<string> temp = lis;
            InsertionSort(temp);
            return temp;
        }

        private void RemButt_Click(object sender, EventArgs e)
        {
            int loc = BinSearch(playlistBox.SelectedItem.ToString());
            if (loc != 99999999)
            {
                SongList.RemoveAt(loc);
            }
            PopulateSongList();
        }
        private int BinSearch(String tar)
        {
            int curCheck;
            char curChar;
            char checkChar;
            int pointCheck = 0;
            int attempts = 0;
            curCheck = (SongList.Count / 2);
            bool looper = true;
            while (looper)
            {
                curChar = tar[pointCheck];
                checkChar = SongList[curCheck][pointCheck];
                if (tar == SongList[curCheck])
                {
                    looper = false;//breaks the loop
                    return curCheck;//returns the location of the item
                }
                else if (curChar == checkChar)
                {
                    pointCheck++;
                    attempts++;
                }
                else if (curChar < checkChar)
                {
                    if (curCheck == 1)
                    {
                        curCheck = 0;
                        attempts++;
                    }
                    curCheck = (curCheck / 2);
                }
                else if (curChar > checkChar)
                {
                    curCheck = (curCheck + 1);
                    attempts++;
                }
                if ((attempts == (SongList.Count + 20)) || (SongList[curCheck] == null))
                {
                    MessageBox.Show("Could not find matching entry after " + attempts + " attempts ending search");
                    looper = false;
                    return 99999999;//returns max int value to allow a search to read as failed
                }


            }
            return 0;
        }

        private void l5SaveBut_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Tracklist";
            save.InitialDirectory = @"C:\Users";
            save.FilterIndex = 1;
            save.RestoreDirectory = true;
            if (save.ShowDialog() == DialogResult.OK)
            {
                if (!save.FileName.EndsWith("v"))
                {
                    save.FileName += ".csv";
                }
                using (var write = new StreamWriter(save.FileName))
                using (var csv = new CsvWriter(write, CultureInfo.InvariantCulture))
                {

                    foreach (var song in last5Box.Items)
                    {
                        string songs = song.ToString();
                        csv.WriteField<String>(songs);
                        csv.NextRecord();
                    }

                }
            }
        }

        private void loadBut_Click(object sender, EventArgs e)
        {
            OpenFileDialog load = new OpenFileDialog();
            load.Title = "load Tracklist";
            load.InitialDirectory = @"C:\Users";
            load.Filter = "Csv files (*.csv)|*.csv";
            load.FilterIndex = 1;
            load.RestoreDirectory = true;
            if (load.ShowDialog() == DialogResult.OK)
            {
                string fileloc = load.FileName;
                using (var reader = new StreamReader(fileloc))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    while (true)
                    {
                        csv.Read();
                        try
                        {
                            String temp = csv.GetField<String>(0);
                            SongList.Add(temp);
                            PopulateSongList();
                        }
                        catch (Exception)
                        {
                            break;
                        }

                    }
                }
            }
        }
    }

}
