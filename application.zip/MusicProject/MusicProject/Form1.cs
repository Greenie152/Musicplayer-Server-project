﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Timers;
using System.IO;
using CsvHelper;
using System.Globalization;

namespace MusicProject
{
    public partial class MainForm : Form
    {
        private connect connection;
        bool logged = false;
        public MainForm()
        {
            InitializeComponent();
            StartClient();
        }

        List<string> SongList = new List<string>();
        private void PopulateListBox()
        {
            trackListBox.Items.Clear();
            foreach (string song in SongList)
            {
                trackListBox.Items.Add(song);
            }
        }
        private void PlaySong(string song)
        {
            musicPlay.URL = song;//a method that uses ax windows media player to play a song at the location supplied into the method
        }

        private void connButt_Click(object sender, EventArgs e)
        {
            connection.Connect("\\\\.\\pipe\\musicpipe");
            connButt.Enabled = false;
            LoginBut.Enabled = true;
        }
        void MessageRec(byte[] message)
        {
            Invoke(new connect.MessageReceivedHandler(DisplayMessageReceived),
                new object[] { message });
        }
        void DisplayMessageReceived(byte[] message)
        {
            ASCIIEncoding encoder = new ASCIIEncoding();
            string code1 = encoder.GetString(message, 0, message.Length);
            string checker = (code1[0]).ToString();
            bool conSucc = false;
            try
            {
                if(Hashing.Verify("DoneConn", code1))
                {
                    conSucc = true;
                }
            }
            catch
            {
                
            }
            if (conSucc)//checks for the connection confirmation
            {
                connButt.Enabled = false;
                serReqBut.Enabled = true;
                MessageBox.Show("connected.");
                logged = true;
            }
            else if (checker == "!")//if the inital value is the flag charecter for a sent list
            {
                int count = 0;
                String temp = "";//sets checker variables
                foreach(char ch in code1)//loops through the message
                {
                    if (count <= 1)//skips over the flag charecter without excluding later exclamation marks
                    {
                        count++;
                    }
                    else if(ch.ToString() == ",")//checks for the flag of next item
                    {
                        SongList.Add(temp);
                        temp = "";//adds the built value to the list then clears temp
                    }
                    else//any other charecter
                    {
                        temp += ch;//builds temp into a complete item
                    }
                }
                PopulateListBox();
            }
            else//only other message type will be connection refusal so that is confirmed
            {
                MessageBox.Show("Incorrect passkey");
            }
        }

        private void trackListBox_DoubleClick(object sender, EventArgs e)
        {
            int indcheck = BinSearch(trackListBox.SelectedItem.ToString());
            if(indcheck != 99999999)
            {
                PlaySong(SongList[indcheck]);
                if (logged)
                {
                    String code = "!" + SongList[indcheck];
                    ASCIIEncoding ec = new ASCIIEncoding();
                    connection.SendMessage(ec.GetBytes(code));
                }
            }
            
        }

        private void addBut_Click(object sender, EventArgs e)
        {
            OpenFileDialog browser = new OpenFileDialog();
            browser.Title = "Add Song";
            browser.InitialDirectory = @"C:\Users";
            //browser.Filter = "Music files (*.mp3,*.wav)|*.mp3, *.wav";
            browser.FilterIndex = 1;
            browser.RestoreDirectory = true;//creates a browser that allows the user to pick the file they want to add
            if (browser.ShowDialog() == DialogResult.OK)
            {
                string songloc = browser.FileName;
                SongList.Add(songloc);//if the file browser gets an option saves the url to the list
            }
            if (SongList.Count >= 2)
            {
                SortList();//sorts the list after a new element was added
            }
            else
            {
                PopulateListBox();
            }

        }

        private void remBut_Click(object sender, EventArgs e)
        {
            int loc = BinSearch(trackListBox.SelectedItem.ToString());
            if (loc != 99999999)
            {
                SongList.RemoveAt(loc);
            }
            PopulateListBox();
        }

        private void serReqBut_Click(object sender, EventArgs e)
        {
            if (connection.Connected)
            {
                ASCIIEncoding ec = new ASCIIEncoding();
                String code = "S3ndPl@ylist1!";
                code = Hashing.Hash(code);
                connection.SendMessage(ec.GetBytes(code));
            }
        }
        private void SortList()
        {
            List<string> InsList = new List<string>(SongList);
            InsList = (InsSort(SongList));
            SongList = InsList;
            PopulateListBox();
        }
        static List<string> InsertionSort(List<string> sorter)
        {
            for (int i = 0; i < sorter.Count - 1; i++)
            {
                for (int j = i + 1; j > 0; j--)
                {
                    if (sorter[j - 1].CompareTo(sorter[j]) > 0)
                    {
                        string temp = sorter[j - 1];
                        sorter[j - 1] = sorter[j];
                        sorter[j] = temp;
                    }
                }
            }
            return sorter;
        }
        static public List<string> InsSort(List<string> lis)
        {
            List<string> temp = lis;
            InsertionSort(temp);
            return temp;
        }

        private void saveButt_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save Tracklist";
            save.InitialDirectory = @"C:\Users";
            save.FilterIndex = 1;
            save.RestoreDirectory = true;
            if (save.ShowDialog() == DialogResult.OK)
            {
                if (!save.FileName.EndsWith("v"))
                {
                    save.FileName += ".csv";
                }
                using (var write = new StreamWriter(save.FileName))
                using (var csv = new CsvWriter(write, CultureInfo.InvariantCulture))
                {

                    foreach (var song in SongList)
                    {
                        csv.WriteField<String>(song);
                        csv.NextRecord();
                    }

                }
            }

        }

        private void loadBut_Click(object sender, EventArgs e)
        {
            OpenFileDialog load = new OpenFileDialog();
            load.Title = "load Tracklist";
            load.InitialDirectory = @"C:\Users";
            load.Filter = "Csv files (*.csv)|*.csv";
            load.FilterIndex = 1;
            load.RestoreDirectory = true;
            if (load.ShowDialog() == DialogResult.OK)
            {
                string fileloc = load.FileName;
                using (var reader = new StreamReader(fileloc))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    while (true)
                    {
                        csv.Read();
                        try
                        {
                            String temp = csv.GetField<String>(0);
                            SongList.Add(temp);
                            PopulateListBox();
                        }
                        catch (Exception)
                        {
                            break;
                        }

                    }
                }
            }

        }
        private int BinSearch(String tar)
        {
            int curCheck;
            char curChar;
            char checkChar;
            int pointCheck = 0;
            int attempts = 0;
            curCheck = (SongList.Count / 2);
            bool looper = true;
            while (looper)
            {
                curChar = tar[pointCheck];
                checkChar = SongList[curCheck][pointCheck];
                if (tar == SongList[curCheck])
                {
                    looper = false;//breaks the loop
                    return curCheck;//returns the location of the item
                }
                else if (curChar == checkChar)
                {
                    pointCheck++;
                    attempts++;
                }
                else if (curChar < checkChar)
                {
                    if (curCheck == 1)
                    {
                        curCheck = 0;
                        attempts++;
                    }
                    curCheck = (curCheck / 2);
                }
                else if (curChar > checkChar)
                {
                    curCheck = (curCheck + 1);
                    attempts++;
                }
                if ((attempts == (SongList.Count + 20)) || (SongList[curCheck] == null))
                {
                    MessageBox.Show("Could not find matching entry after " + attempts + " attempts ending search");
                    looper = false;
                    return 99999999;//returns max int value to allow a search to read as failed
                }


            }
            return 0;
        }

        private void LoginBut_Click(object sender, EventArgs e)
        {
            String code = keyBox.Text.ToString();
            ASCIIEncoding ec = new ASCIIEncoding();
            code = Hashing.Hash(code);//hashes passkey
            connection.SendMessage(ec.GetBytes(code));
        }
        void StartClient()
        {
            if (connection != null)
            {
                connection.MessageReceived -= MessageRec;
            }

            connection = new connect();
            connection.MessageReceived += MessageRec;
        }
    }
}
