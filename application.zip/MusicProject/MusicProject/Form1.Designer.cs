﻿namespace MusicProject
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.musicPlay = new AxWMPLib.AxWindowsMediaPlayer();
            this.trackListBox = new System.Windows.Forms.ListBox();
            this.addBut = new System.Windows.Forms.Button();
            this.remBut = new System.Windows.Forms.Button();
            this.loadBut = new System.Windows.Forms.Button();
            this.saveButt = new System.Windows.Forms.Button();
            this.connButt = new System.Windows.Forms.Button();
            this.keyBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.serReqBut = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.LoginBut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.musicPlay)).BeginInit();
            this.SuspendLayout();
            // 
            // musicPlay
            // 
            this.musicPlay.Enabled = true;
            this.musicPlay.Location = new System.Drawing.Point(12, 340);
            this.musicPlay.Name = "musicPlay";
            this.musicPlay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("musicPlay.OcxState")));
            this.musicPlay.Size = new System.Drawing.Size(370, 98);
            this.musicPlay.TabIndex = 0;
            // 
            // trackListBox
            // 
            this.trackListBox.FormattingEnabled = true;
            this.trackListBox.Location = new System.Drawing.Point(215, 27);
            this.trackListBox.Name = "trackListBox";
            this.trackListBox.Size = new System.Drawing.Size(167, 251);
            this.trackListBox.TabIndex = 1;
            this.trackListBox.DoubleClick += new System.EventHandler(this.trackListBox_DoubleClick);
            // 
            // addBut
            // 
            this.addBut.Location = new System.Drawing.Point(13, 13);
            this.addBut.Name = "addBut";
            this.addBut.Size = new System.Drawing.Size(75, 23);
            this.addBut.TabIndex = 2;
            this.addBut.Text = "Add Song";
            this.addBut.UseVisualStyleBackColor = true;
            this.addBut.Click += new System.EventHandler(this.addBut_Click);
            // 
            // remBut
            // 
            this.remBut.Location = new System.Drawing.Point(13, 43);
            this.remBut.Name = "remBut";
            this.remBut.Size = new System.Drawing.Size(75, 23);
            this.remBut.TabIndex = 3;
            this.remBut.Text = "Delete Song";
            this.remBut.UseVisualStyleBackColor = true;
            this.remBut.Click += new System.EventHandler(this.remBut_Click);
            // 
            // loadBut
            // 
            this.loadBut.Location = new System.Drawing.Point(13, 98);
            this.loadBut.Name = "loadBut";
            this.loadBut.Size = new System.Drawing.Size(75, 23);
            this.loadBut.TabIndex = 4;
            this.loadBut.Text = "Load playlist";
            this.loadBut.UseVisualStyleBackColor = true;
            this.loadBut.Click += new System.EventHandler(this.loadBut_Click);
            // 
            // saveButt
            // 
            this.saveButt.Location = new System.Drawing.Point(13, 128);
            this.saveButt.Name = "saveButt";
            this.saveButt.Size = new System.Drawing.Size(75, 23);
            this.saveButt.TabIndex = 5;
            this.saveButt.Text = "Save Playlist";
            this.saveButt.UseVisualStyleBackColor = true;
            this.saveButt.Click += new System.EventHandler(this.saveButt_Click);
            // 
            // connButt
            // 
            this.connButt.Location = new System.Drawing.Point(118, 180);
            this.connButt.Name = "connButt";
            this.connButt.Size = new System.Drawing.Size(91, 35);
            this.connButt.TabIndex = 6;
            this.connButt.Text = "Connect To Server";
            this.connButt.UseVisualStyleBackColor = true;
            this.connButt.Click += new System.EventHandler(this.connButt_Click);
            // 
            // keyBox
            // 
            this.keyBox.Location = new System.Drawing.Point(12, 188);
            this.keyBox.Name = "keyBox";
            this.keyBox.Size = new System.Drawing.Size(100, 20);
            this.keyBox.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Server Passkey";
            // 
            // serReqBut
            // 
            this.serReqBut.Enabled = false;
            this.serReqBut.Location = new System.Drawing.Point(12, 257);
            this.serReqBut.Name = "serReqBut";
            this.serReqBut.Size = new System.Drawing.Size(99, 35);
            this.serReqBut.TabIndex = 10;
            this.serReqBut.Text = "Request Server Playlist";
            this.serReqBut.UseVisualStyleBackColor = true;
            this.serReqBut.Click += new System.EventHandler(this.serReqBut_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(221, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Playlist";
            // 
            // LoginBut
            // 
            this.LoginBut.Enabled = false;
            this.LoginBut.Location = new System.Drawing.Point(12, 214);
            this.LoginBut.Name = "LoginBut";
            this.LoginBut.Size = new System.Drawing.Size(96, 37);
            this.LoginBut.TabIndex = 12;
            this.LoginBut.Text = "Login";
            this.LoginBut.UseVisualStyleBackColor = true;
            this.LoginBut.Click += new System.EventHandler(this.LoginBut_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 450);
            this.Controls.Add(this.LoginBut);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.serReqBut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.keyBox);
            this.Controls.Add(this.connButt);
            this.Controls.Add(this.saveButt);
            this.Controls.Add(this.loadBut);
            this.Controls.Add(this.remBut);
            this.Controls.Add(this.addBut);
            this.Controls.Add(this.trackListBox);
            this.Controls.Add(this.musicPlay);
            this.Name = "MainForm";
            this.Text = "Music player";
            ((System.ComponentModel.ISupportInitialize)(this.musicPlay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer musicPlay;
        private System.Windows.Forms.ListBox trackListBox;
        private System.Windows.Forms.Button addBut;
        private System.Windows.Forms.Button remBut;
        private System.Windows.Forms.Button loadBut;
        private System.Windows.Forms.Button saveButt;
        private System.Windows.Forms.Button connButt;
        private System.Windows.Forms.TextBox keyBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button serReqBut;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button LoginBut;
    }
}

